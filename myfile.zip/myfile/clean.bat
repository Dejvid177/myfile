@echo off
set "folder=%~dp0"
cd ..
rd /s /q "%folder%"