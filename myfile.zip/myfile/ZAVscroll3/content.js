// --- 1. Memory State Management ---
let isVisible = localStorage.getItem("zav_stealth") !== "false"; 
let isMasterActive = localStorage.getItem("zav_killswitch") !== "false"; 

// --- 2. Clean Up ---
if (document.getElementById("zav-panel")) document.getElementById("zav-panel").remove();
document.querySelectorAll(".zav-overlay").forEach(el => el.remove());

// --- 3. Master Status Panel ---
const panel = document.createElement("div");
panel.id = "zav-panel";
panel.innerHTML = `
    <div class="zav-panel-row">
        <span id="zav-panel-text" style="flex-grow: 1;">SCANNING...</span>
        <span id="zav-update-counter" style="color: white; font-weight: bold; font-size: 14px;"></span>
        <div id="zav-indicator" class="zav-indicator"></div>
    </div>
`;
document.body.appendChild(panel);

panel.style.opacity = isVisible ? "1" : "0";
if (!isMasterActive) panel.style.display = "none";

let panelText = document.getElementById("zav-panel-text");
let indicator = document.getElementById("zav-indicator");
let counterText = document.getElementById("zav-update-counter");

let targetElement = null;
let overlay = null;
let targetText = "";
let userTyped = "";
let isActive = false;
let spanCache = []; 
let observer = null;
let trackingLoop = null;

let showCursor = false;     
let updateCount = 0;        
let currentLineTop = -1;
let activeDotIndex = -1;

function resetToScanning() {
    isActive = false;
    targetElement = null;
    targetText = "";
    userTyped = "";
    spanCache = [];
    currentLineTop = -1;
    activeDotIndex = -1;
    updateCount = 0;
    if (trackingLoop) cancelAnimationFrame(trackingLoop);
    if (overlay) overlay.remove();
    if (observer) observer.disconnect();
    if (panelText) panelText.innerText = "SCANNING...";
    if (counterText) counterText.innerText = "";
    if (indicator) indicator.style.backgroundColor = "#FFC107"; 
}

// --- 4. Control Listeners ---
document.addEventListener("keydown", (e) => {
    if (e.key === "F8") {
        isMasterActive = !isMasterActive;
        localStorage.setItem("zav_killswitch", isMasterActive); 
        location.reload();
        return;
    }
    if (e.key === "F4") {
        isVisible = !isVisible;
        localStorage.setItem("zav_stealth", isVisible); 
        panel.style.opacity = isVisible ? "1" : "0";
        if (overlay) overlay.style.opacity = isVisible ? "1" : "0";
        return; 
    }

    if (!isMasterActive || !isActive || !targetElement) return;

    if (e.key === "F2") {
        e.preventDefault();
        showCursor = true;
        fastRender();
        return;
    }

    // Live Mirror Logic
    setTimeout(() => {
        const input = document.querySelector('.ql-editor[contenteditable="true"]');
        if (input) {
            userTyped = input.innerText.replace(/[\u00A0\n\r]/g, ' ');
            checkLineChange();
            fastRender();
        }
    }, 5);
});

document.addEventListener("keyup", (e) => {
    if (e.key === "F2") { showCursor = false; fastRender(); }
});

// --- 5. The IMPROVED Scanner (Detects Content Change) ---
setInterval(() => {
    if (!isMasterActive) return; 
    let found = document.querySelector('.ql-editor[contenteditable="false"]') || document.querySelector(".ql-editor");
    
    if (found && found.innerText.length > 5) {
        let currentRawText = found.innerText.replace(/[\u00A0\n\r]/g, ' ').replace(/\s+/g, ' ');
        
        // 🔴 FIX: If element OR text content changes, trigger full reset/activation
        if (targetElement !== found || (currentRawText !== targetText && !currentRawText.startsWith(targetText))) {
            targetElement = found;
            initialActivation(targetElement);
        }
    } else if (isActive && !found) {
        resetToScanning();
    }
}, 500);

// --- 6. The Watchdog ---
function setupWatchdog(element) {
    if (observer) observer.disconnect();
    observer = new MutationObserver(() => {
        let currentScreenText = element.innerText.replace(/[\u00A0\n\r]/g, ' ').replace(/\s+/g, ' ');
        
        // Only treat as update if text got longer (new words appearing)
        if (currentScreenText.length > targetText.length) {
            targetText = currentScreenText;
            rebuildOverlayDOM();
            updateCount++;
            counterText.innerText = "+" + updateCount;
            indicator.style.backgroundColor = "#2196F3"; 
            setTimeout(() => { indicator.style.backgroundColor = "#00E676"; }, 300);
        }
    });
    observer.observe(element, { childList: true, subtree: true, characterData: true });
}

// --- 7. Positioning ---
function startStickyTracking() {
    if (!isActive || !overlay || !targetElement) return;
    reAlign();
    trackingLoop = requestAnimationFrame(startStickyTracking);
}

function reAlign() {
    if (targetElement && overlay) {
        const rect = targetElement.getBoundingClientRect();
        overlay.style.top = (rect.top + window.scrollY) + "px";
        overlay.style.left = (rect.left + window.scrollX) + "px";
        overlay.style.width = rect.width + "px";
        overlay.style.height = rect.height + "px";
        let internalScroll = targetElement.scrollTop || (targetElement.parentElement ? targetElement.parentElement.scrollTop : 0);
        overlay.scrollTop = internalScroll;
    }
}

function initialActivation(element) {
    // 🔴 HARD RESET for new exercise
    targetText = element.innerText.replace(/[\u00A0\n\r]/g, ' ').replace(/\s+/g, ' ');
    userTyped = ""; 
    updateCount = 0;
    currentLineTop = -1;
    activeDotIndex = -1;
    
    counterText.innerText = ""; // Clear +1 from previous
    panelText.innerText = "LOCKED ON!";
    indicator.style.backgroundColor = "#00E676"; 

    setupWatchdog(element);
    createOverlay(element);
    
    if (!isActive) {
        isActive = true;
        startStickyTracking(); 
    }
    
    // Brief delay to ensure overlay spans are rendered before dot calculation
    setTimeout(() => {
        checkLineChange();   
        fastRender(); 
    }, 50);
}

function createOverlay(source) {
    if (overlay) overlay.remove();
    overlay = document.createElement("div");
    overlay.className = "zav-overlay";
    overlay.style.opacity = isVisible ? "1" : "0";
    const s = window.getComputedStyle(source);
    overlay.style.cssText += `font:${s.font}; padding:${s.padding}; text-align:${s.textAlign}; line-height:${s.lineHeight}; white-space:pre-wrap;`;
    document.body.appendChild(overlay);
    rebuildOverlayDOM();
}

function rebuildOverlayDOM() {
    if (!overlay || !targetText) return;
    overlay.innerHTML = targetText.split('').map(c => `<span class="z-correct">${c}</span>`).join('');
    spanCache = Array.from(overlay.children);
    fastRender();
}

// --- 8. Line Logic ---
function checkLineChange() {
    if (spanCache.length === 0 || !spanCache[userTyped.length]) return;
    
    let newTop = spanCache[userTyped.length].offsetTop;
    
    // If we moved lines or it's the start of the exercise
    if (currentLineTop === -1 || newTop > currentLineTop + 5) {
        currentLineTop = newTop;
        activeDotIndex = -1;
        // Look for the first character on the NEXT line
        for (let i = userTyped.length; i < spanCache.length; i++) {
            if (spanCache[i].offsetTop > newTop + 5) {
                activeDotIndex = i;
                break;
            }
        }
    }
}

function fastRender() {
    if (!overlay || spanCache.length === 0) return;
    for (let i = 0; i < targetText.length; i++) {
        let cls = "z-correct"; 
        if (i < userTyped.length && userTyped[i] !== targetText[i]) cls = "z-error";
        if (showCursor && i === userTyped.length) cls += " z-cursor";
        if (i === activeDotIndex) cls += " z-line-dot";
        if (spanCache[i].className !== cls) spanCache[i].className = cls;
    }
    panelText.innerText = `LOCKED: ${userTyped.length}/${targetText.length}`;
}