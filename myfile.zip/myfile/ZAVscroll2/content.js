// --- 1. Memory State Management ---
let isVisible = localStorage.getItem("zav_stealth") !== "false"; 
let isMasterActive = localStorage.getItem("zav_killswitch") !== "false"; 

// --- 2. Clean Up Old Stuff ---
if (document.getElementById("zav-panel")) document.getElementById("zav-panel").remove();
document.querySelectorAll(".zav-overlay").forEach(el => el.remove());

// --- 3. Create the Master Status Panel ---
const panel = document.createElement("div");
panel.id = "zav-panel";
panel.innerHTML = `
    <div class="zav-panel-row">
        <span id="zav-panel-text" style="flex-grow: 1;">SCANNING...</span>
        <span id="zav-update-counter" style="color: white; font-weight: bold; font-size: 14px;"></span>
        <div id="zav-indicator" class="zav-indicator"></div>
    </div>
`;
document.body.appendChild(panel);

panel.style.opacity = isVisible ? "1" : "0";
if (!isMasterActive) panel.style.display = "none";

let panelText = document.getElementById("zav-panel-text");
let indicator = document.getElementById("zav-indicator");
let counterText = document.getElementById("zav-update-counter");

let targetElement = null;
let overlay = null;
let targetText = "";
let userTyped = "";
let isActive = false;
let spanCache = []; 
let observer = null;
let trackingLoop = null; // Used for the 60fps tracking

// --- Features State ---
let showCursor = false;     
let updateCount = 0;        

// --- Line Control State ---
let currentLineTop = -1;
let activeDotIndex = -1;
let dotTimer = null;

function resetToScanning() {
    isActive = false;
    targetElement = null;
    targetText = "";
    userTyped = "";
    spanCache = [];
    currentLineTop = -1;
    activeDotIndex = -1;
    
    if (trackingLoop) {
        cancelAnimationFrame(trackingLoop);
        trackingLoop = null;
    }
    if (overlay) {
        overlay.remove();
        overlay = null;
    }
    if (observer) {
        observer.disconnect();
        observer = null;
    }
    
    if (panelText) panelText.innerText = "SCANNING...";
    if (counterText) counterText.innerText = "";
    if (indicator) indicator.style.backgroundColor = "#FFC107"; 
}

// --- 4. GLOBAL KEY Listeners ---
document.addEventListener("keydown", (e) => {
    if (e.key === "F8") {
        e.preventDefault();
        isMasterActive = !isMasterActive;
        localStorage.setItem("zav_killswitch", isMasterActive); 
        if (isMasterActive) {
            location.reload(); 
        } else {
            resetToScanning();
            panel.style.display = "none";
        }
        return;
    }

    if (e.key === "F4") {
        e.preventDefault();
        isVisible = !isVisible;
        localStorage.setItem("zav_stealth", isVisible); 
        panel.style.opacity = isVisible ? "1" : "0";
        if (overlay) overlay.style.opacity = isVisible ? "1" : "0";
        return; 
    }

    if (!isMasterActive || !isActive || !targetElement || targetText.length === 0) return;

    if (e.key === "F2") {
        e.preventDefault();
        if (!showCursor) {
            showCursor = true;
            fastRender();
        }
        return;
    }

    if (e.key === "Backspace") {
        if (userTyped.length > 0) {
            userTyped = userTyped.slice(0, -1);
            checkLineChange();
        }
    } else if (e.key.length === 1) {
        userTyped += e.key;
        checkLineChange();
    }
    fastRender();
});

document.addEventListener("keyup", (e) => {
    if (e.key === "F2") {
        showCursor = false;
        fastRender();
    }
});

// --- 5. The "Scanner" Loop ---
const scanner = setInterval(() => {
    if (!isMasterActive) return; 

    // 🔴 FIX 1: Explicitly search for the source text box, not the typing box
    let found = document.querySelector('.ql-editor[contenteditable="false"]');
    
    // Fallback if there is only one box anyway
    if (!found) found = document.querySelector(".ql-editor");

    if (found && found.innerText.length > 5) {
        if (targetElement !== found) {
            targetElement = found;
            initialActivation(targetElement);
        }
    } else if (isActive && !found) {
        resetToScanning();
    }
}, 500);

// --- 6. Watchdog ---
function setupWatchdog(element) {
    if (observer) observer.disconnect();
    observer = new MutationObserver(() => {
        let currentScreenText = element.innerText.replace(/[\u00A0\n\r]/g, ' ').replace(/\s+/g, ' ');
        if (currentScreenText.length > targetText.length) {
            targetText = currentScreenText;
            rebuildOverlayDOM();
            updateCount++;
            counterText.innerText = "+" + updateCount;
            fastRender();
            indicator.style.backgroundColor = "#2196F3"; 
            setTimeout(() => { indicator.style.backgroundColor = "#00E676"; }, 300);
        }
    });
    observer.observe(element, { childList: true, subtree: true, characterData: true });
}

// --- 7. Sticky Tracking & Activation ---
function startStickyTracking() {
    if (!isActive || !overlay || !targetElement) return;
    reAlign();
    trackingLoop = requestAnimationFrame(startStickyTracking);
}

function reAlign() {
    if (targetElement && overlay) {
        const rect = targetElement.getBoundingClientRect();
        const scrollY = window.scrollY || window.pageYOffset;
        const scrollX = window.scrollX || window.pageXOffset;
        
        overlay.style.top = (rect.top + scrollY) + "px";
        overlay.style.left = (rect.left + scrollX) + "px";
        overlay.style.width = rect.width + "px";
        overlay.style.height = rect.height + "px";
        
        // 🔴 FIX 2: Copy the internal scroll of the ZAV text box perfectly
        let internalScroll = targetElement.scrollTop;
        if (internalScroll === 0 && targetElement.parentElement) {
            internalScroll = targetElement.parentElement.scrollTop;
        }
        overlay.scrollTop = internalScroll;
    }
}

function initialActivation(element) {
    targetText = element.innerText.replace(/[\u00A0\n\r]/g, ' ').replace(/\s+/g, ' ');
    userTyped = ""; 
    updateCount = 0;
    counterText.innerText = "";
    panelText.innerText = "LOCKED ON!";
    indicator.style.backgroundColor = "#00E676"; 

    setupWatchdog(element);
    createOverlay(element);
    
    if (!isActive) {
        window.addEventListener("resize", reAlign);
        isActive = true;
        startStickyTracking(); // Start the 60fps tracking
    }
    
    currentLineTop = -1; 
    checkLineChange();   
    fastRender(); 
}

function createOverlay(source) {
    if (overlay) overlay.remove();
    overlay = document.createElement("div");
    overlay.className = "zav-overlay";
    overlay.style.opacity = isVisible ? "1" : "0";
    
    const style = window.getComputedStyle(source);
    overlay.style.font = style.font;
    overlay.style.fontFamily = style.fontFamily;
    overlay.style.fontSize = style.fontSize;
    overlay.style.fontWeight = style.fontWeight;
    overlay.style.lineHeight = style.lineHeight;
    overlay.style.letterSpacing = style.letterSpacing;
    overlay.style.padding = style.padding; 
    overlay.style.textAlign = style.textAlign;
    overlay.style.whiteSpace = "pre-wrap"; 

    document.body.appendChild(overlay);
    rebuildOverlayDOM();
}

function rebuildOverlayDOM() {
    if (!overlay || !targetElement) return;
    reAlign();
    let html = "";
    for (let i = 0; i < targetText.length; i++) {
        html += `<span class="z-correct">${targetText[i]}</span>`;
    }
    overlay.innerHTML = html;
    spanCache = Array.from(overlay.children);
    if (userTyped.length > 0) checkLineChange(); 
}

// --- 8. Line Control Logic ---
function checkLineChange() {
    if (spanCache.length === 0 || !spanCache[userTyped.length]) return;
    let newTop = spanCache[userTyped.length].offsetTop;
    if (currentLineTop === -1) {
        currentLineTop = newTop;
        setDotToNextLine(newTop);
    } else if (newTop > currentLineTop + 5) {
        currentLineTop = newTop;
        if (dotTimer) clearTimeout(dotTimer);
        dotTimer = setTimeout(() => {
            setDotToNextLine(currentLineTop);
            fastRender(); 
        }, 5000);
    }
}

function setDotToNextLine(baseTop) {
    activeDotIndex = -1;
    for (let i = userTyped.length; i < spanCache.length; i++) {
        if (spanCache[i].offsetTop > baseTop + 5) {
            activeDotIndex = i;
            break;
        }
    }
}

// --- 9. ULTRA-FAST RENDERER ---
function fastRender() {
    if (!overlay || spanCache.length === 0) return;
    for (let i = 0; i < targetText.length; i++) {
        let neededClass = "z-correct"; 
        if (i < userTyped.length && userTyped[i] !== targetText[i]) {
            neededClass = "z-error";
        }
        if (showCursor && i === userTyped.length) {
            neededClass += " z-cursor";
        }
        if (i === activeDotIndex) {
            neededClass += " z-line-dot";
        }
        if (spanCache[i] && spanCache[i].className !== neededClass) {
            spanCache[i].className = neededClass;
        }
    }
    panelText.innerText = `LOCKED: ${userTyped.length} / ${targetText.length}`;
}