(async function() {
    // --- 1. Secure Storage ---
    let store;
    try {
        store = await chrome.storage.local.get(["_u_st", "_u_ks"]);
    } catch (e) {
        store = { _u_st: true, _u_ks: true };
    }
    
    let isVisible = store._u_st !== false;
    let isMasterActive = store._u_ks !== false;

    // --- 2. Isolated UI (Shadow DOM) ---
    // Host is the only thing on the main page; Shadow Root hides the rest.
    const host = document.createElement("div");
    host.id = "sys-" + Math.random().toString(36).substring(7);
    const shadow = host.attachShadow({ mode: 'closed' });
    document.documentElement.appendChild(host);

    const sheet = document.createElement("style");
    sheet.textContent = `
        ._pnl { position: fixed; top: 10px; right: 10px; background: #1cabb2; color: white; padding: 8px 12px; border-radius: 4px; font-family: monospace; z-index: 2147483647; font-size: 12px; transition: opacity 0.2s; pointer-events: auto; }
        ._ovl { position: fixed; pointer-events: none; z-index: 2147483646; color: transparent; white-space: pre-wrap; transition: opacity 0.2s; }
        ._err { background-color: rgba(255, 0, 0, 0.15); border-bottom: 1px solid red; }
        ._cor { color: transparent; }
    `;
    shadow.appendChild(sheet);

    const panel = document.createElement("div");
    panel.className = "_pnl";
    panel.style.opacity = isVisible ? "1" : "0";
    if (!isMasterActive) panel.style.display = "none";
    shadow.appendChild(panel);

    // --- 3. Core Logic ---
    let targetElement = null;
    let overlay = null;
    let targetTextRaw = "";
    let targetGraphemes = [];
    let userGraphemes = [];
    let isActive = false;
    let spanCache = [];

    const segmenter = (typeof Intl !== "undefined" && Intl.Segmenter) ? new Intl.Segmenter(undefined, { granularity: "grapheme" }) : null;

    function splitG(text) {
        if (!text) return [];
        return segmenter ? Array.from(segmenter.segment(text), s => s.segment) : Array.from(text);
    }

    document.addEventListener("keydown", (e) => {
        if (e.key === "F8") {
            chrome.storage.local.set({ "_u_ks": !isMasterActive }, () => location.reload());
            return;
        }
        if (e.key === "F4") {
            isVisible = !isVisible;
            chrome.storage.local.set({ "_u_st": isVisible });
            panel.style.opacity = isVisible ? "1" : "0";
            if (overlay) overlay.style.opacity = isVisible ? "1" : "0";
            return;
        }
        
        if (!isMasterActive || !isActive) return;

        if (e.key === "Backspace") {
            userGraphemes.pop();
        } else if (e.key.length === 1 && !e.ctrlKey && !e.altKey) {
            userGraphemes.push(e.key);
        }
        render();
    });

    function scan() {
        if (!isMasterActive) return;
        const found = document.querySelector('.ql-editor[contenteditable="false"]') || document.querySelector(".ql-editor");
        if (found && found.textContent.trim().length > 5) {
            if (targetElement !== found) {
                targetElement = found;
                activate(found);
            }
        }
    }

    function activate(el) {
        targetTextRaw = el.textContent || "";
        targetGraphemes = splitG(targetTextRaw);
        userGraphemes = [];
        
        if (overlay) overlay.remove();
        overlay = document.createElement("div");
        overlay.className = "_ovl";
        overlay.style.opacity = isVisible ? "1" : "0";
        
        const s = window.getComputedStyle(el);
        overlay.style.font = s.font;
        overlay.style.lineHeight = s.lineHeight;
        overlay.style.padding = s.padding;
        
        shadow.appendChild(overlay);
        overlay.innerHTML = targetGraphemes.map(g => `<span class="_cor">${g === " " ? "&nbsp;" : g}</span>`).join('');
        spanCache = Array.from(overlay.children);
        isActive = true;
    }

    function render() {
        if (!overlay || spanCache.length === 0) return;
        const userLen = userGraphemes.length;
        for (let i = 0; i < targetGraphemes.length; i++) {
            let cls = "_cor";
            if (i < userLen) {
                const typed = userGraphemes[i];
                const expected = targetGraphemes[i].replace(/\u00A0/g, " ");
                if (typed !== expected) cls = "_err";
            }
            if (spanCache[i].className !== cls) spanCache[i].className = cls;
        }
        panel.innerText = `READY: ${userLen}/${targetGraphemes.length}`;
        
        const r = targetElement.getBoundingClientRect();
        overlay.style.top = (r.top + window.scrollY) + "px";
        overlay.style.left = (r.left + window.scrollX) + "px";
        overlay.style.width = r.width + "px";
        overlay.style.height = r.height + "px";
    }

    setInterval(scan, 1000);
    setInterval(() => { if(isActive) render(); }, 150);
})();