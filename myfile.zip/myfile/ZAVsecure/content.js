(async function() {
    // --- 1. Secure Storage ---
    let store = await chrome.storage.local.get(["_u_st", "_u_ks"]);
    let isVisible = store._u_st !== false;
    let isMasterActive = store._u_ks !== false;

    // --- 2. Shadow DOM Setup ---
    const host = document.createElement("div");
    host.id = "sys-" + Math.random().toString(36).substring(7);
    const shadow = host.attachShadow({ mode: 'closed' });
    document.documentElement.appendChild(host);

    const sheet = document.createElement("style");
    sheet.textContent = `
        ._pnl { position: fixed; top: 10px; right: 10px; background: #1cabb2; color: white; padding: 8px 12px; border-radius: 4px; font-family: monospace; z-index: 2147483647; font-size: 12px; pointer-events: none; }
        ._ovl { position: fixed; pointer-events: none; z-index: 2147483646; color: transparent; white-space: pre-wrap; word-break: break-all; overflow: hidden; }
        ._err { background-color: rgba(255, 0, 0, 0.25); border-bottom: 2px solid red; }
        ._cor { color: transparent; }
    `;
    shadow.appendChild(sheet);

    const panel = document.createElement("div");
    panel.className = "_pnl";
    panel.style.display = isMasterActive ? "block" : "none";
    panel.style.opacity = isVisible ? "1" : "0";
    shadow.appendChild(panel);

    let targetElement = null, overlay = null, targetGraphemes = [], userGraphemes = [], spanCache = [];

    // --- 3. Advanced Text Logic ---
    // Treats \u00A0 and normal spaces identically for error checking
    const normalize = (t) => (t || "").replace(/\u00A0/g, " ").normalize("NFC");

    const segmenter = new Intl.Segmenter(undefined, { granularity: "grapheme" });
    const splitG = (t) => Array.from(segmenter.segment(t), s => s.segment);

    function syncStyles(from, to) {
        const s = window.getComputedStyle(from);
        const props = [
            'font-family', 'font-size', 'font-weight', 'line-height', 
            'letter-spacing', 'word-spacing', 'padding', 'text-align', 
            'text-indent', 'text-transform', 'box-sizing'
        ];
        props.forEach(p => to.style[p] = s[p]);
    }

    function activate(el) {
        // Use innerText to preserve actual line breaks instead of flattening them
        let rawText = el.innerText || el.textContent || "";
        rawText = rawText.replace(/\r\n/g, '\n'); 
        
        targetGraphemes = splitG(rawText);
        userGraphemes = [];
        if (overlay) overlay.remove();
        
        overlay = document.createElement("div");
        overlay.className = "_ovl";
        syncStyles(el, overlay);
        
        shadow.appendChild(overlay);
        
        // Map elements precisely. Keep \u00A0 intact in the DOM to enforce identical word wrapping.
        overlay.innerHTML = targetGraphemes.map(g => {
            if (g === '\n') return `<span class="_cor"><br></span>`;
            if (g === ' ') return `<span class="_cor">&nbsp;</span>`;
            return `<span class="_cor">${g}</span>`;
        }).join('');
        
        spanCache = Array.from(overlay.children);
    }

    function render() {
        if (!overlay || !targetElement) return;
        
        // Real-time position and scroll syncing
        const r = targetElement.getBoundingClientRect();
        overlay.style.top = r.top + "px";
        overlay.style.left = r.left + "px";
        overlay.style.width = r.width + "px";
        overlay.style.height = r.height + "px";
        overlay.scrollTop = targetElement.scrollTop;
        overlay.scrollLeft = targetElement.scrollLeft;

        const userLen = userGraphemes.length;
        spanCache.forEach((span, i) => {
            let cls = "_cor";
            if (i < userLen) {
                if (normalize(userGraphemes[i]) !== normalize(targetGraphemes[i])) cls = "_err";
            }
            if (span.className !== cls) span.className = cls;
        });
        panel.innerText = `OK: ${userLen}/${targetGraphemes.length}`;
    }

    // --- 4. The Dead-Key Logic Engine ---
    let pendingDeadKey = null;

    document.addEventListener("keydown", (e) => {
        if (e.key === "F8") {
            chrome.storage.local.set({ "_u_ks": !isMasterActive }, () => location.reload());
            return;
        }
        if (e.key === "F4") {
            isVisible = !isVisible;
            chrome.storage.local.set({ "_u_st": isVisible });
            panel.style.opacity = isVisible ? "1" : "0";
            if (overlay) overlay.style.opacity = isVisible ? "1" : "0";
            return;
        }

        if (!isMasterActive || !targetElement) return;

        if (e.key === "Backspace") {
            userGraphemes.pop();
            pendingDeadKey = null;
        } else if (e.key === "Enter") {
            userGraphemes.push("\n");
            pendingDeadKey = null;
        } else if (e.key === "Dead") {
            pendingDeadKey = "ˇ"; // Store memory of the dead key
            userGraphemes.push("ˇ");
        } else if (e.key.length === 1 && !e.ctrlKey && !e.altKey) {
            if (pendingDeadKey) {
                userGraphemes.pop(); // Remove the placeholder dead key
                
                // If e.key is standard ASCII (like 'm' or 'f'), the OS failed to combine the characters.
                // It means the website registered TWO characters (ˇ and m). We must push both.
                const isFailedComposition = /^[\x00-\x7F]*$/.test(e.key);
                
                if (isFailedComposition) {
                    userGraphemes.push(pendingDeadKey);
                    userGraphemes.push(e.key);
                } else {
                    // It combined successfully! (e.key is 'ň'). Push just the one character.
                    userGraphemes.push(e.key);
                }
                pendingDeadKey = null;
            } else {
                userGraphemes.push(e.key);
            }
        } else {
            pendingDeadKey = null; // Clear if they hit shift/ctrl/etc
        }
        
        render(); // Force render immediately on keypress
    });

    // --- 5. Real-Time Observers ---
    // Listen to ALL scrolling on the page to lock the overlay instantly
    window.addEventListener('scroll', render, true); 

    setInterval(() => {
        const found = document.querySelector('.ql-editor');
        if (found && found !== targetElement) {
            targetElement = found;
            activate(found);
        }
        if (targetElement) render(); // Failsafe render loop
    }, 200);
})();