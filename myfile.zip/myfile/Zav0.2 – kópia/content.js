let isVisible = localStorage.getItem("_z_s_") !== "false"; 
let isMasterActive = localStorage.getItem("_z_k_") !== "false"; 

if (document.getElementById("_qx_71")) document.getElementById("_qx_71").remove();
document.querySelectorAll("._ov_x2").forEach(el => el.remove());

const panel = document.createElement("div");
panel.id = "_qx_71";
panel.innerHTML = `
    <span id="_uc_44">0</span>
    <div id="_ir_09" class="_ir_09"></div>
`;
document.body.appendChild(panel);

panel.style.opacity = isVisible ? "1" : "0";
if (!isMasterActive) panel.style.display = "none";

let indicator = document.getElementById("_ir_09");
let counterText = document.getElementById("_uc_44");

let targetElement = null;
let overlay = null;
let targetText = "";
let userTyped = "";
let isActive = false;
let spanCache = []; 
let observer = null;

let showCursor = false;     
let updateCount = 0;        
let currentLineTop = -1;
let activeDotIndex = -1;
let dotTimer = null;

document.addEventListener("keydown", (e) => {
    if (e.key === "F8") {
        e.preventDefault();
        isMasterActive = !isMasterActive;
        localStorage.setItem("_z_k_", isMasterActive); 
        location.reload(); 
        return;
    }
    if (e.key === "F4") {
        e.preventDefault();
        isVisible = !isVisible;
        localStorage.setItem("_z_s_", isVisible); 
        panel.style.opacity = isVisible ? "1" : "0";
        if (overlay) overlay.style.opacity = isVisible ? "1" : "0";
        return; 
    }
    if (!isMasterActive || !isActive || !targetElement || targetText.length === 0) return;
    if (e.key === "F2") {
        e.preventDefault();
        if (!showCursor) { showCursor = true; fastRender(); }
        return;
    }
    if (e.key === "Backspace") {
        if (userTyped.length > 0) { userTyped = userTyped.slice(0, -1); checkLineChange(); }
    } else if (e.key.length === 1) {
        userTyped += e.key; checkLineChange();
    }
    fastRender();
});

document.addEventListener("keyup", (e) => { if (e.key === "F2") { showCursor = false; fastRender(); } });

const scanner = setInterval(() => {
    if (!isMasterActive) return; 
    const found = document.querySelector(".ql-editor");
    if (found && found.innerText.length > 5) {
        if (targetElement !== found) {
            targetElement = found;
            initialActivation(targetElement);
        }
    } else if (isActive && !found) {
        isActive = false;
        targetElement = null;
        if (overlay) { overlay.remove(); overlay = null; }
        if (indicator) indicator.style.backgroundColor = "#FFC107";
    }
}, 500);

function setupWatchdog(element) {
    if (observer) observer.disconnect();
    observer = new MutationObserver(() => {
        let currentScreenText = element.innerText.replace(/[\u00A0\n\r]/g, ' ').replace(/\s+/g, ' ');
        if (currentScreenText.length > targetText.length) {
            targetText = currentScreenText;
            rebuildOverlayDOM();
            updateCount++;
            counterText.innerText = "+" + updateCount;
            fastRender();
            indicator.style.backgroundColor = "#2196F3"; 
            setTimeout(() => { indicator.style.backgroundColor = "#00E676"; }, 300);
        }
    });
    observer.observe(element, { childList: true, subtree: true, characterData: true });
}

function initialActivation(element) {
    targetText = element.innerText.replace(/[\u00A0\n\r]/g, ' ').replace(/\s+/g, ' ');
    userTyped = ""; 
    updateCount = 0;
    counterText.innerText = "0";
    indicator.style.backgroundColor = "#00E676";
    setupWatchdog(element);
    createOverlay(element);
    if (!isActive) { window.addEventListener("resize", reAlign); isActive = true; }
    currentLineTop = -1; 
    checkLineChange();   
    fastRender(); 
}

function createOverlay(source) {
    if (overlay) overlay.remove();
    overlay = document.createElement("div");
    overlay.className = "_ov_x2";
    overlay.style.opacity = isVisible ? "1" : "0";
    const style = window.getComputedStyle(source);
    overlay.style.font = style.font;
    overlay.style.fontFamily = style.fontFamily;
    overlay.style.fontSize = style.fontSize;
    overlay.style.fontWeight = style.fontWeight;
    overlay.style.lineHeight = style.lineHeight;
    overlay.style.letterSpacing = style.letterSpacing;
    overlay.style.padding = style.padding; 
    overlay.style.textAlign = style.textAlign;
    overlay.style.whiteSpace = "pre-wrap"; 
    document.body.appendChild(overlay);
    rebuildOverlayDOM();
}

function rebuildOverlayDOM() {
    if (!overlay || !targetElement) return;
    reAlign();
    let html = "";
    for (let i = 0; i < targetText.length; i++) { html += `<span class="_cr_11">${targetText[i]}</span>`; }
    overlay.innerHTML = html;
    spanCache = Array.from(overlay.children);
    if (userTyped.length > 0) checkLineChange(); 
}

function reAlign() {
    if (targetElement && overlay) {
        const rect = targetElement.getBoundingClientRect();
        const scrollY = window.scrollY || window.pageYOffset;
        const scrollX = window.scrollX || window.pageXOffset;
        overlay.style.top = (rect.top + scrollY) + "px";
        overlay.style.left = (rect.left + scrollX) + "px";
        overlay.style.width = rect.width + "px";
        overlay.style.height = rect.height + "px";
    }
}

function checkLineChange() {
    if (spanCache.length === 0 || !spanCache[userTyped.length]) return;
    let newTop = spanCache[userTyped.length].offsetTop;
    if (currentLineTop === -1) {
        currentLineTop = newTop;
        setDotToNextLine(newTop);
    } else if (newTop > currentLineTop + 5) {
        currentLineTop = newTop;
        if (dotTimer) clearTimeout(dotTimer);
        dotTimer = setTimeout(() => { setDotToNextLine(currentLineTop); fastRender(); }, 5000);
    }
}

function setDotToNextLine(baseTop) {
    activeDotIndex = -1;
    for (let i = userTyped.length; i < spanCache.length; i++) {
        if (spanCache[i].offsetTop > baseTop + 5) { activeDotIndex = i; break; }
    }
}

function fastRender() {
    if (!overlay || spanCache.length === 0) return;
    for (let i = 0; i < targetText.length; i++) {
        let neededClass = "_cr_11"; 
        if (i < userTyped.length && userTyped[i] !== targetText[i]) neededClass = "_er_88";
        if (showCursor && i === userTyped.length) neededClass += " _cs_33";
        if (i === activeDotIndex) neededClass += " _ld_55";
        if (spanCache[i] && spanCache[i].className !== neededClass) spanCache[i].className = neededClass;
    }
}