// --- 1. Memory State Management ---
let isVisible = localStorage.getItem("zav_stealth") !== "false"; 
let isMasterActive = localStorage.getItem("zav_killswitch") !== "false"; 

// --- 2. Clean Up ---
if (document.getElementById("zav-panel")) document.getElementById("zav-panel").remove();
document.querySelectorAll(".zav-overlay").forEach(el => el.remove());

// --- 3. Master Status Panel ---
const panel = document.createElement("div");
panel.id = "zav-panel";
panel.innerHTML = `
    <div class="zav-panel-row">
        <span id="zav-panel-text" style="flex-grow: 1;">SCANNING...</span>
        <span id="zav-update-counter" style="color: white; font-weight: bold; font-size: 14px;"></span>
        <div id="zav-indicator" class="zav-indicator"></div>
    </div>
`;
document.body.appendChild(panel);

panel.style.opacity = isVisible ? "1" : "0";
if (!isMasterActive) panel.style.display = "none";

let panelText = document.getElementById("zav-panel-text");
let indicator = document.getElementById("zav-indicator");
let counterText = document.getElementById("zav-update-counter");

let targetElement = null;
let overlay = null;
let targetTextRaw = "";
let targetGraphemes = [];
let userTyped = "";
let userGraphemes = [];
let isActive = false;
let spanCache = []; 
let observer = null;
let trackingLoop = null;
let inputElement = null;
let scrollParent = null;
let isComposing = false;
let lastInputEventAt = 0;
let lastBeforeInputAt = 0;
let renderQueued = false;

// --- MOJE PRIDANÉ PRAVIDLÁ PRE MÄKČENE A DĹŽNE ---
let pendingDeadType = null; 
const listAcute = ['q','w','t','p','d','f','g','h','j','k','x','v','b','m'];
const listCaron = ['q','w','u','i','o','p','a','f','g','h','j','k','y','x','v','b','m'];

const graphemeSegmenter = (typeof Intl !== "undefined" && Intl.Segmenter)
    ? new Intl.Segmenter(undefined, { granularity: "grapheme" })
    : null;

let showCursor = false;     
let updateCount = 0;        
let currentLineTop = -1;
let activeDotIndex = -1;

function normalizeSourceText(text) {
    return text.replace(/\r\n?/g, "\n").replace(/\u00A0/g, " ");
}

function splitGraphemes(text) {
    if (!text) return [];
    if (graphemeSegmenter) {
        return Array.from(graphemeSegmenter.segment(text), s => s.segment);
    }
    return Array.from(text);
}

function normalizeCompareGrapheme(g) {
    return g.replace(/\u00A0/g, " ").normalize("NFC");
}

function setTargetText(raw) {
    targetTextRaw = normalizeSourceText(raw || "");
    targetGraphemes = splitGraphemes(targetTextRaw);
}

function setUserText(raw) {
    userTyped = raw || "";
    userGraphemes = splitGraphemes(userTyped);
}

function appendUserText(str) {
    if (!str) return;
    userGraphemes.push(...splitGraphemes(str));
    userTyped = userGraphemes.join("");
}

function removeLastUserGrapheme() {
    if (userGraphemes.length === 0) return;
    userGraphemes.pop();
    userTyped = userGraphemes.join("");
}

function escapeHtmlChar(str) {
    if (str === "&") return "&amp;";
    if (str === "<") return "&lt;";
    if (str === ">") return "&gt;";
    return str;
}

function scheduleRender() {
    if (renderQueued) return;
    renderQueued = true;
    requestAnimationFrame(() => {
        renderQueued = false;
        fastRender();
    });
}

function getScrollParent(el) {
    let node = el;
    while (node && node !== document.body) {
        const s = window.getComputedStyle(node);
        if (/(auto|scroll|overlay)/.test(s.overflowY)) return node;
        node = node.parentElement;
    }
    return null;
}

function syncOverlayStyles(source) {
    const s = window.getComputedStyle(source);
    Object.assign(overlay.style, {
        fontFamily: s.fontFamily,
        fontSize: s.fontSize,
        fontWeight: s.fontWeight,
        fontStyle: s.fontStyle,
        lineHeight: s.lineHeight,
        letterSpacing: s.letterSpacing,
        textAlign: s.textAlign,
        whiteSpace: "pre-wrap",
        padding: s.padding,
        boxSizing: "border-box",
        wordBreak: "break-all",
        transformOrigin: "top left"
    });
}

function resetToScanning() {
    isActive = false;
    targetElement = null;
    targetTextRaw = "";
    targetGraphemes = [];
    setUserText("");
    spanCache = [];
    currentLineTop = -1;
    activeDotIndex = -1;
    updateCount = 0;
    pendingDeadType = null;
    if (trackingLoop) cancelAnimationFrame(trackingLoop);
    if (overlay) overlay.remove();
    if (observer) observer.disconnect();
    detachInput();
    scrollParent = null;
    if (panelText) panelText.innerText = "SCANNING...";
    if (counterText) counterText.innerText = "";
    if (indicator) indicator.style.backgroundColor = "#FFC107"; 
}

// --- 4. Control Listeners ---
document.addEventListener("keydown", (e) => {
    if (e.key === "F8") {
        isMasterActive = !isMasterActive;
        localStorage.setItem("zav_killswitch", isMasterActive); 
        location.reload();
        return;
    }
    if (e.key === "F4") {
        isVisible = !isVisible;
        localStorage.setItem("zav_stealth", isVisible); 
        panel.style.opacity = isVisible ? "1" : "0";
        if (overlay) overlay.style.opacity = isVisible ? "1" : "0";
        return; 
    }

    // --- NOVA FUNKCIA: OPAKOVANIE TEXTU ---
    if (e.key === "F9") {
        if (!targetTextRaw) return;
        setTargetText(targetTextRaw + " " + targetTextRaw); 
        rebuildOverlayDOM();
        panelText.innerText = "TEXT REPEATED!";
        return;
    }

    if (!isMasterActive || !isActive || !targetElement) return;

    if (e.key === "F2") {
        e.preventDefault();
        showCursor = true;
        scheduleRender();
        return;
    }

    // --- SPRACOVANIE DĹŽŇOV A MÄKČEŇOV ---
    if (e.key === "Dead") {
        pendingDeadType = e.shiftKey ? 'caron' : 'acute';
        return;
    }

    if (pendingDeadType) {
        const keyLower = e.key.toLowerCase();
        if (pendingDeadType === 'acute' && listAcute.includes(keyLower)) {
            appendUserText("´");
            appendUserText(e.key);
        } else if (pendingDeadType === 'caron' && listCaron.includes(keyLower)) {
            appendUserText("ˇ");
            appendUserText(e.key);
        } else {
            appendUserText(e.key);
        }
        pendingDeadType = null;
        checkLineChange();
        scheduleRender();
        return;
    }

    if (inputElement && document.contains(inputElement)) return;
    const now = performance.now();
    if (now - lastInputEventAt < 25 || e.isComposing) return;

    if (e.key === "Backspace") {
        removeLastUserGrapheme();
    } else if (e.key === "Enter") {
        appendUserText("\n");
    } else if (e.key === "Tab") {
        // --- MODIFIED: IGNORE TAB KEY ENTIRELY ---[cite: 1]
        e.preventDefault(); 
        return; 
    } else if (e.key.length === 1) {
        appendUserText(e.key);
    } else {
        return;
    }

    checkLineChange();
    scheduleRender();
});

document.addEventListener("keyup", (e) => {
    if (e.key === "F2") { showCursor = false; scheduleRender(); }
});

// --- 5. Scanner & Watchdog ---
function findTargetElement() {
    const scrollable = document.querySelector("scrollable-text");
    if (scrollable) {
        const rect = scrollable.getBoundingClientRect();
        const hit = document.elementFromPoint(rect.left + rect.width / 2, rect.top + rect.height / 2);
        if (hit && scrollable.contains(hit)) {
            let cur = hit;
            while (cur && cur !== scrollable) {
                if ((cur.textContent || "").length > 10) return cur;
                cur = cur.parentElement;
            }
        }
    }
    return document.querySelector('.ql-editor[contenteditable="false"]') || document.querySelector(".ql-editor");
}

function attachInput(el) {
    if (!el || inputElement === el) return;
    detachInput();
    inputElement = el;
    inputElement.addEventListener("beforeinput", handleBeforeInput, true);
    inputElement.addEventListener("input", handleInput, true);
}

function detachInput() {
    if (!inputElement) return;
    inputElement.removeEventListener("beforeinput", handleBeforeInput, true);
    inputElement.removeEventListener("input", handleInput, true);
    inputElement = null;
}

function handleBeforeInput(e) {
    lastBeforeInputAt = performance.now();
    if (!isMasterActive || !isActive || e.isComposing) return;
    const type = e.inputType || "";
    if (type.startsWith("delete")) { removeLastUserGrapheme(); } 
    else if (type === "insertLineBreak") { appendUserText("\n"); } 
    else if (type === "insertText" && e.data != null) { appendUserText(e.data); }
    lastInputEventAt = performance.now();
    checkLineChange();
    scheduleRender();
}

function handleInput(e) {
    const now = performance.now();
    if (now - lastBeforeInputAt < 25 || !isMasterActive || !isActive || e.isComposing) return;
    const type = e.inputType || "";
    if (type.startsWith("delete")) { removeLastUserGrapheme(); } 
    else if ((type === "insertText") && e.data != null) { appendUserText(e.data); }
    lastInputEventAt = performance.now();
    checkLineChange();
    scheduleRender();
}

function scanAndActivate() {
    if (!isMasterActive) return;
    const hiddenInput = document.querySelector("textarea.hidden-textbox");
    if (hiddenInput) attachInput(hiddenInput);
    const found = findTargetElement();
    if (found && found.textContent && found.textContent.trim().length > 5) {
        const currentRawText = normalizeSourceText(found.textContent);
        if (targetElement !== found || currentRawText !== targetTextRaw) {
            targetElement = found;
            initialActivation(targetElement);
        }
    } else if (isActive && !found) {
        resetToScanning();
    }
}
setInterval(scanAndActivate, 800);

function initialActivation(element) {
    setTargetText(element.textContent || "");
    setUserText("");
    updateCount = 0;
    scrollParent = getScrollParent(element);
    panelText.innerText = "LOCKED ON!";
    indicator.style.backgroundColor = "#00E676"; 
    createOverlay(element);
    if (!isActive) {
        isActive = true;
        startStickyTracking(); 
    }
}

function createOverlay(source) {
    if (overlay) overlay.remove();
    overlay = document.createElement("div");
    overlay.className = "zav-overlay";
    overlay.style.opacity = isVisible ? "1" : "0";
    syncOverlayStyles(source);
    document.body.appendChild(overlay);
    rebuildOverlayDOM();
}

function rebuildOverlayDOM() {
    if (!overlay || targetGraphemes.length === 0) return;
    overlay.innerHTML = targetGraphemes.map(g => `<span class="z-correct">${escapeHtmlChar(g)}</span>`).join('');
    spanCache = Array.from(overlay.children);
    scheduleRender();
}

function startStickyTracking() {
    if (!isActive || !overlay || !targetElement) return;
    const rect = targetElement.getBoundingClientRect();
    overlay.style.top = rect.top + "px";
    overlay.style.left = rect.left + "px";
    overlay.style.width = rect.width + "px";
    overlay.style.height = rect.height + "px";
    const scroller = scrollParent || (targetElement.scrollHeight > targetElement.clientHeight ? targetElement : null);
    overlay.scrollTop = scroller ? scroller.scrollTop : 0;
    trackingLoop = requestAnimationFrame(startStickyTracking);
}

function checkLineChange() {
    if (spanCache.length === 0 || !spanCache[userGraphemes.length]) return;
    let newTop = spanCache[userGraphemes.length].offsetTop;
    if (currentLineTop === -1 || newTop > currentLineTop + 5) {
        currentLineTop = newTop;
        activeDotIndex = -1;
        for (let i = userGraphemes.length; i < spanCache.length; i++) {
            if (spanCache[i].offsetTop > newTop + 5) {
                activeDotIndex = i;
                break;
            }
        }
    }
}

function fastRender() {
    if (!overlay || spanCache.length === 0) return;
    const userLen = userGraphemes.length;
    const targetLen = targetGraphemes.length;
    for (let i = 0; i < targetLen; i++) {
        let cls = "z-correct"; 
        if (i < userLen) {
            const expected = normalizeCompareGrapheme(targetGraphemes[i]);
            const typed = normalizeCompareGrapheme(userGraphemes[i] || "");
            if (typed !== expected) cls = "z-error";
        }
        if (showCursor && i === userLen) cls += " z-cursor";
        if (i === activeDotIndex) cls += " z-line-dot";
        if (spanCache[i].className !== cls) spanCache[i].className = cls;
    }
    panelText.innerText = `LOCKED: ${userLen}/${targetLen}`;
}