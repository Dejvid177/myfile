Set WshShell = WScript.CreateObject("WScript.Shell")

' 1. Open Chrome with the Default profile
WshShell.Run "chrome.exe --profile-directory=""Default"""

' 2. Wait 1.5 seconds for Chrome to fully open (1500 milliseconds)
WScript.Sleep 1500 

' 3. Type the extensions URL
WshShell.SendKeys "chrome://extensions/"

' 4. Press the Enter key
WshShell.SendKeys "{ENTER}"